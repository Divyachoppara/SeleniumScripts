package TESTS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BASE_CLASSES.Utilities;
import EXCEL.Read_excel;
import PAGES.Add_to_cart;
import PAGES.Added_page;
import PAGES.Click_register;
import PAGES.Click_sign_in;
import PAGES.Login_page;
import PAGES.Register_page;
import PAGES.Search_page;

public class Test_Jpet extends Read_excel {
	WebDriver driver;
	Utilities ult;
	Click_sign_in csi;
	Click_register cr;
	Register_page Rp;
	Login_page Lp;
	Search_page sp;
	Add_to_cart ac;
	Added_page ap;
	@BeforeClass
	public void bfc() 
	{
		ult=new Utilities(driver);
		get_data();
		
	}
	@BeforeMethod
	public void bfm() 
	{
		driver=ult.Launch_browser("CHROME", "https://jpetstore.cfapps.io/catalog");
		csi=new Click_sign_in(driver);
		cr=new Click_register(driver);
		Rp=new Register_page(driver);
		Lp=new Login_page(driver);
		sp=new Search_page(driver);
		ac=new Add_to_cart(driver);
		ap=new Added_page(driver);
	}
  @Test(dataProvider="loginpage")
  public void f(String un,String pd,String cpd,String nm,String ln,String eml,String ph,String a1,String a2,String ct,String st,String zp,String ctr,String uid,String pwd) 
  {
	  csi.clk_on_signin();
	  cr.clk_on_register();
	  String phn=ph.substring(1, 10);
	  String zpc=zp.substring(1, 6);
	  Rp.do_reg(un,pd,cpd,nm,ln,eml,phn,a1,a2,ct,st,zpc,ctr);
	  cr.clk_on_register();
	  Lp.Login(uid,pwd);
	  sp.search();
	  ac.add_product();
	  ap.adding();
	  
  }
  @DataProvider(name="loginpage")
  public String[][] Provide_data()
  {
	  return testdata;
  }
  
}
